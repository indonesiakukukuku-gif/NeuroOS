import time
import os

def sentinel_pulse():
    log_path = "logs/sentinel.log"
    # Pastikan folder logs ada
    if not os.path.exists("logs"):
        os.makedirs("logs")
        
    print("🛡️ AI GUARD SENTINEL: [ONLINE]")
    while True:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        status = "[PULSE] 10,000 IIDs Secure | Riba: 0% | Aura: Distributed"
        
        with open(log_path, "a") as f:
            f.write(f"[{timestamp}] {status}\n")
        
        # Output ke konsol agar terlihat di tmux
        print(f"[{timestamp}] {status}", flush=True)
        time.sleep(60) # Detak jantung setiap 1 menit

if __name__ == "__main__":
    sentinel_pulse()
